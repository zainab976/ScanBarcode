import 'dart:io';

import 'package:device_info_plus/device_info_plus.dart';
import 'package:price_scanner_app/blocs/item.bloc.dart';
import 'package:price_scanner_app/services/naviagation.service.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:get_it/get_it.dart';
import 'dart:math';

import '../vendor/network_analyzer.dart';
import 'base.bloc.dart';

class SettingsPageBloc implements BlocBase {
  List<String> ipAddresses = [];
  late String deviceId;
  late String deviceName;
  late String selectedIP = '';

  SettingsPageBloc() {
    // _initSystem();
    _getIpAddress();
    _getDeviceId();
  }

  _initSystem() async {
    final prefs = await SharedPreferences.getInstance();
    if (prefs.containsKey('ipaddress')) {
      selectedIP = prefs.getString('ipaddress').toString();
      if (prefs.containsKey('deviceId')) {
        deviceId = prefs.getString('deviceId').toString();
        goToItemPage();
      }
    }
  }

  _getIpAddress() async {
    List<NetworkInterface> netWorkInterface = await NetworkInterface.list();
    if (netWorkInterface.isNotEmpty &&
        netWorkInterface[0].addresses.isNotEmpty) {
      String address = netWorkInterface[0].addresses[0].address;
      String subnet = address.substring(0, address.lastIndexOf("."));
      int port = 5600;

      final stream = NetworkAnalyzer.discover2(subnet, port);
      stream.listen((NetworkAddress addr) {
        if (addr.exists) {
          ipAddresses.add(addr.ip.toString());
        }
      });
    }
  }

  setIP(String ip) {
    selectedIP = ip;
  }

  setSystemVars() async {
    final prefs = await SharedPreferences.getInstance();
    if (selectedIP != '') {
      await prefs.setString('ipaddress', selectedIP);
    }
    // if (deviceName != null && deviceName != '') {
    //   await prefs.setString('deviceName', deviceName);
    // }
    if (deviceId != '') {
      await prefs.setString('deviceId', deviceId);
    }
  }

  _getDeviceId() async {
    DeviceInfoPlugin deviceInfo = DeviceInfoPlugin();

    if (Platform.isWindows) {
      WindowsDeviceInfo windowsDeviceInfo = await deviceInfo.windowsInfo;
      deviceId = windowsDeviceInfo.deviceId.toString();
    } else if (Platform.isAndroid) {
      AndroidDeviceInfo androidInfo = await deviceInfo.androidInfo;
      deviceId = androidInfo.id.toString();
    }
  }

  goToItemPage() {
    GetIt.instance
        .get<NavigationService>()
        .goToItemPage(ItemPageBloc(selectedIP, deviceId));
  }

  void connect() {
    setSystemVars();
    goToItemPage();
  }

  @override
  void dispose() {
    // TODO: implement dispose
  }
}
