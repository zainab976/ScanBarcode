import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:price_scanner_app/blocs/item.bloc.dart';
import 'package:price_scanner_app/models/product.dart';
import 'vendor/resize/resize.dart';
import 'setting.dart';

class itemDetails extends StatefulWidget {
  ItemPageBloc bloc;
  itemDetails({super.key, required this.bloc});

  @override
  State<itemDetails> createState() => _itemDetailsState();
}

class _itemDetailsState extends State<itemDetails> {
  bool isDesktop(BuildContext context) =>
      MediaQuery.of(context).size.width >= 500;

  bool isMobile(BuildContext context) =>
      MediaQuery.of(context).size.width < 500;

  Timer? timer;
  String barcode = "";

  bool itemView = false;
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<bool>(
        initialData: true,
        stream: widget.bloc.connectionStatus.stream,
        builder: (context, snapshot) {
          if (snapshot.data!) {
            return RawKeyboardListener(
              focusNode: FocusNode(),
              autofocus: true,
              onKey: (event) async {
                if (event.logicalKey.keyLabel == "Enter") {
                  String tempBarcode = barcode;
                  barcode = "";
                  if (await widget.bloc.scanBarcode(tempBarcode)) {
                    setState(() {
                      itemView = true;
                    });
                    if (timer != null) timer!.cancel();
                    timer = Timer(
                        const Duration(
                            seconds: 30), //the wanted duration for the timer
                        () {
                      setState(() {
                        itemView = false;
                      });
                    });
                  }
                } else {
                  if (event.character != null) {
                    barcode += event.character!;
                  }
                }
              },
              child: Scaffold(
                backgroundColor: Color.fromARGB(255, 2, 59, 112),
                body: itemView ? itemWidget() : scanWidget(),
              ),
            );
          } else {
            return Scaffold(
                backgroundColor: Color.fromARGB(255, 2, 59, 112),
                body: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        child: Text(
                          "No Connection",
                          style: TextStyle(
                            fontSize: 57.sp,
                            color: Colors.white,
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 12,
                      ),
                      FloatingActionButton.extended(
                        label: Text('GO Back'),
                        backgroundColor: Color.fromARGB(255, 3, 135, 124),
                        icon: Icon(
                          Icons
                              .navigate_before, //arrow_back //arrow_back //navigate_before
                          size: 24.0,
                        ),
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) {
                                return SettingPage();
                              },
                            ),
                          );
                        },
                      ),
                    ],
                  ),
                ));
          }
        });
  }

  Widget itemWidget() {
    if (widget.bloc.product == null) {
      return Center(
        child: Text(
          "Item Not Found",
          style: TextStyle(
            fontSize: 120.sp,
            color: Colors.white,
          ),
        ),
      );
    }

    Product product = widget.bloc.product!;

    List<Widget> widgets = [];
    if (isDesktop(context)) {
      widgets = [itemImage(product), itemDetails(product)];
    } else {
      widgets = [itemDetails(product)];
    }

    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: widgets,
    );
  }

  Widget itemImage(Product product) {
    return Expanded(
      flex: 2,
      child: Container(
        color: const Color.fromARGB(255, 204, 239, 245),
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(43.0),
            child: product.defaultImage == ""
                ? Card(
                    color: Color.fromARGB(255, 140, 140, 138),
                    elevation: 12,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(25.0)),
                    child: Padding(
                        padding: const EdgeInsets.all(18.0),
                        child: Container(
                          child: Text(
                            "No Image",
                            style: TextStyle(
                              fontSize: 63.sp,
                            ),
                          ),
                        )))
                : Card(
                    elevation: 12,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(25.0)),
                    child: Padding(
                      padding: const EdgeInsets.all(18.0),
                      child: Image(
                        image: MemoryImage(base64Decode(product.defaultImage)),
                      ),

                      // child: Card(
                      //   //color: Colors.yellow,
                      //   elevation: 12,
                      //   shape: RoundedRectangleBorder(
                      //       borderRadius: BorderRadius.circular(25.0)),
                      //   child: Padding(
                      //     padding: const EdgeInsets.all(18.0),
                      //     child: product.defaultImage == ""
                      //         ? Container(
                      //             /// color: Color.fromARGB(255, 255, 255, 255),
                      //             child: Text(
                      //               "No Image",
                      //               style: TextStyle(
                      //                 fontSize: 63.sp,
                      //                 // backgroundColor: Color.fromARGB(115, 158, 4, 4),
                      //               ),
                      //             ),
                      //           )
                      //         : Image(
                      //             image: MemoryImage(base64Decode(product.defaultImage)),
                      //           ),
                    ),
                  ),
          ),
        ),
      ),
    );
  }

  Widget itemDetails(Product product) {
    return Expanded(
      flex: 2,
      child: Container(
        color: const Color.fromARGB(255, 0, 63, 143),
        child: Padding(
          padding: EdgeInsets.only(left: 32.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(
                height: 180.h,
              ),
              SizedBox(
                child: Text(
                  product.name,
                  style: TextStyle(
                      fontSize: 70.sp,
                      color: Colors.white,
                      fontWeight: FontWeight.bold),
                ),
              ),
              SizedBox(
                height: 75.h,
              ),
              SizedBox(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "price",
                      style: TextStyle(
                        fontSize: 34.sp,
                        color: Colors.white,
                      ),
                    ),
                    Text(
                      product.price.toString(),
                      style: TextStyle(
                          fontSize: 70.sp,
                          color: Colors.white,
                          fontWeight: FontWeight.bold),
                    )
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget scanWidget() {
    return Stack(children: [
      Center(
        child: Column(
          children: [
            SizedBox(
              height: 18.h,
            ),
            Expanded(
              flex: 5,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(25.0.r),
                child: const Image(
                  image: AssetImage(
                    'assets/barcode-scan.gif',
                  ),
                ),
              ),
            ),
            Container(
              padding: EdgeInsets.symmetric(vertical: 10.h),
              height: 100.h,
              child: Text(
                "SCAN HERE",
                style: TextStyle(
                  fontSize: 63.sp,
                  fontWeight: FontWeight.bold,
                  color: Color.fromRGBO(12, 229, 233, 1).withOpacity(1.0),
                ),
              ),
            ),
            SizedBox(
              height: 2.h,
            ),
            // ignore: prefer_const_constructors
            Expanded(
                flex: 2,
                child: const Image(image: AssetImage('assets/down-arrow.png'))),
          ],
        ),
      ),
    ]);
  }
}
