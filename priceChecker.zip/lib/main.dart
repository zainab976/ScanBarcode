import 'package:flutter/material.dart';
import 'package:price_scanner_app/setting.dart';
import 'vendor/resize/resize.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // Initialize ResizeUtil using Resize()
    return Resize(
      size: const Size(1280, 800),
      allowtextScaling: false,
      builder: () {
        return const MaterialApp(
          debugShowCheckedModeBanner: false,
          home: SettingPage(),
        );
      },
    );
  }
}
